package com.snow.enums;

public enum EnvironmentType {
	LOCAL,
	REMOTE,
}
