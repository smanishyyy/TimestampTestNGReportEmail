package com.snow.util;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;

public class EmailSent {

	public static void main(String arg[]) throws EmailException {

		String path = "C:/Users/chaurma/Downloads/Project/STRY0020317/SnowNowPageObjectFramework/target/Extent Cucumber-reports/Report.html";
		// sendEmail(path);
	}

	public static void sendEmail(String text, String strFailCount, String strPassCount) throws EmailException {
		EmailAttachment attachment = new EmailAttachment();
		attachment.setPath(text);
		attachment.setDisposition(EmailAttachment.ATTACHMENT);

		// Create the email message
		MultiPartEmail email = new MultiPartEmail();
		email.setHostName("mail.manulife.com");
		email.addTo("MChaurasia@jhancock.com", "Manish Chaurasia");
		email.addTo("PPodder@jhancock.com", "Payel");
		email.addTo("Maitri_Sarkar@jhancock.com", "Maitri");
		email.addTo("Sumit_Shaw@jhanco                 ck.com", "Sumit");
		email.addTo("Joyeesha_Paul@jhancock.com", "Joyeesha");
		email.addTo("Debarati_Kundu@jhancock.com", "Debarati");
		email.addTo("AKThakur@jhancock.com", "Amarkant");
		email.addTo("KRatnam@jhancock.com", "Keshav");

		email.setFrom("MChaurasia@jhancock.com", "Manish Chaurasia");
		email.setSubject("Failure : Execution of MF-IBM Change");
		email.setMsg("Hi All" + "\n" + "\n" + "<-----This email is being triggerd without Jenkins----->" + "\n" + "\n"
				+ "Please find the execution status" + "\n" + "\n" + "Passed test case count : " + strPassCount + "\n"
				+ "Failed test case count : " + strFailCount + "\n" + "\n"
				+ "To get the details  please open the attachment and let me know if you have any concern" + "\n" + "\n"
				+ "As a testing purpose to check the email functionality , this email triggers always without rule vaidation of Pass\\Fail."
				+ "\n" + "\n" + "Warm Regards" + "\n" + "Manish Chaurasia" + "\n"
				+ "MChaurais@jhancock.com | johnhancock.com");
		// add the attachment
		email.attach(attachment);
		email.send();

	}

	public static void sendEmail2(String text, String strFailCount, String strPassCount) throws EmailException {
		EmailAttachment attachment = new EmailAttachment();
		attachment.setPath(text);
		attachment.setDisposition(EmailAttachment.ATTACHMENT);

		// Create the email message
		MultiPartEmail email = new MultiPartEmail();
		email.setHostName("mail.manulife.com");
		email.addTo("MChaurasia@jhancock.com", "Manish Chaurasia");
		email.addTo("PPodder@jhancock.com", "Payel");
		email.addTo("Maitri_Sarkar@jhancock.com", "Maitri");
		email.addTo("Sumit_Shaw@jhancock.com", "Sumit");
		email.addTo("Joyeesha_Paul@jhancock.com", "Joyeesha");
		email.addTo("Debarati_Kundu@jhancock.com", "Debarati");
		email.addTo("AKThakur@jhancock.com", "Amarkant");
		email.addTo("KRatnam@jhancock.com", "Keshav");
		email.setFrom("MChaurasia@jhancock.com", "Manish Chaurasia");
		email.setSubject("Success : Regression report of MLF-IBM Change");
		email.setMsg("Hi All" + "\n" + "\n" + "<-----This email is being triggerd without Jenkins----->" + "\n" + "\n"
				+ "Please find the execution status" + "\n" + "\n" + "Passed test case count : " + strPassCount + "\n"
				+ "Failed test case count : " + strFailCount + "\n" + "\n"
				+ "To get the details  please open the attachment and let me know if you have any concern" + "\n" + "\n"
				+ "As a testing purpose to check the email functionality , this email triggers always without rule vaidation of Pass\\Fail."
				+ "\n" + "\n" + "Warm Regards" + "\n" + "Manish Chaurasia" + "\n"
				+ "MChaurais@jhancock.com | johnhancock.com");
		// add the attachment
		email.attach(attachment);
		email.send();

	}
}
